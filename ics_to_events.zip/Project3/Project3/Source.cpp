#include <iostream>
#include <fstream>
#include <string>
using namespace std;

string formatTime(const string& dt) {
    if (dt.length() < 15) return dt;

    string year = dt.substr(0, 4);
    string month = dt.substr(4, 2);
    string day = dt.substr(6, 2);
    string hour = dt.substr(9, 2);
    string min = dt.substr(11, 2);

    int h = stoi(hour);
    string period = "AM";

    if (h >= 12) {
        period = "PM";
        if (h > 12) h -= 12;
    }
    if (h == 0) h = 12;

    return month + "/" + day + "/" + year + " " + to_string(h) + ":" + min + " " + period;
}

int main() {
    ifstream file("uaa-student.ics");
    ofstream out("events.txt");

    string line, name, start, end, type;
    bool inEvent = false;

    while (getline(file, line)) {
        if (line == "BEGIN:VEVENT") {
            inEvent = true;
            name = start = end = type = "";
        }

        if (inEvent) {
            if (line.rfind("SUMMARY:", 0) == 0)
                name = line.substr(8);

            if (line.rfind("DTSTART", 0) == 0) {
                start = formatTime(line.substr(line.find(":") + 1));
            }

            if (line.rfind("DTEND", 0) == 0) {
                end = formatTime(line.substr(line.find(":") + 1));
            }

            if (line.find("X-TRUMBA-CUSTOMFIELD;NAME=\"Event Type\"") != string::npos) {
                type = line.substr(line.find(":") + 1);
            }
        }

        if (line == "END:VEVENT") {
            out << name << " | " << start << " | " << end << " | " << type << "\n";
            inEvent = false;
        }
    }

    cout << "Saved to events.txt in parse-friendly format!" << endl;
    return 0;
}
